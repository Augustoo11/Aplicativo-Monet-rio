package com.Projeto.GestorFin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorFinApplicationTests {

	@Test
	void contextLoads() {
	}

}
